import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-6 py-16">

        <div className="grid md:grid-cols-4 gap-12">

          <div>
            <h2 className="text-2xl font-bold">Loanify</h2>

            <p className="mt-4 text-gray-600 leading-relaxed">
              Modern lending solutions designed to help individuals and businesses achieve financial freedom.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Company</h3>

            <div className="mt-4 space-y-3 text-gray-600">
              <Link href="#" className="block">About</Link>
              <Link href="#" className="block">Careers</Link>
              <Link href="#" className="block">Contact</Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Loans</h3>

            <div className="mt-4 space-y-3 text-gray-600">
              <Link href="#" className="block">Personal Loans</Link>
              <Link href="#" className="block">Business Loans</Link>
              <Link href="#" className="block">Home Loans</Link>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Legal</h3>

            <div className="mt-4 space-y-3 text-gray-600">
              <Link href="#" className="block">Privacy Policy</Link>
              <Link href="#" className="block">Terms & Conditions</Link>
            </div>
          </div>

        </div>

        <div className="mt-16 border-t border-gray-200 pt-8 text-sm text-gray-500 flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© 2026 Loanify. All rights reserved.</p>

          <p>Secure • Transparent • Trusted</p>
        </div>
      </div>
    </footer>
  );
}