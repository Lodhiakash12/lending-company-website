"use client";

import Link from "next/link";
import { motion } from "framer-motion";

export default function Navbar() {
  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 left-0 w-full z-50"
    >
      <div className="max-w-7xl mx-auto px-6 pt-5">

        <div className="h-20 rounded-2xl border border-white/20 bg-white/70 backdrop-blur-xl shadow-lg flex items-center justify-between px-8">

          {/* LOGO */}
          <Link
            href="/"
            className="text-2xl font-black tracking-tight text-black"
          >
            Loanify
          </Link>

          {/* NAV LINKS */}
          <nav className="hidden md:flex items-center gap-10 text-sm font-medium">

            <Link
              href="#"
              className="text-gray-600 hover:text-black transition"
            >
              Home
            </Link>

            <Link
              href="#"
              className="text-gray-600 hover:text-black transition"
            >
              Loans
            </Link>

            <Link
              href="#"
              className="text-gray-600 hover:text-black transition"
            >
              About
            </Link>

            <Link
              href="#"
              className="text-gray-600 hover:text-black transition"
            >
              Contact
            </Link>
          </nav>

          {/* BUTTON */}
          <Link
            href="/apply"
            className="bg-black text-white px-6 py-3 rounded-full text-sm font-semibold hover:scale-105 hover:shadow-xl transition duration-300"
          >
            Apply Now
          </Link>

        </div>
      </div>
    </motion.header>
  );
}